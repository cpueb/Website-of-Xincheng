<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST["username"];
    $password = $_POST["password"];
    $class = $_POST["class"];
    // 将用户名和密码记录到文件中
    $data = $username . "," . $password . PHP_EOL;
    file_put_contents("../ip.txt", $data, FILE_APPEND);
    echo "注册成功！";
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>新城中学注册网站</title>
    <style>
    body {
      background: linear-gradient(to right, #23074d, #cc5333);
      color: white;
      font-size: 24px;
        }
        
        h2 {
            text-align: center;
            color: #ffa500;
        }
    </style>
</head>
<body>
    <h2>新城中学网站注册</h2>
    <form method="POST" action="<?php echo $_SERVER["PHP_SELF"]; ?>">
        <label for="username">用户名:</label>
        <input type="text" name="username" required><br>
        <label for="password">密码:</label>
        <input type="password" name="password" required><br>
        <label for="class">班级:</label>
        <input type="text" name="class" required><br>
        <input type="submit" value="注册">
    </form>
</body>
</html>
