<?php
session_start();
// 检查用户是否已登录，如果未登录则跳转到登录页面
if(!isset($_SESSION['username'])){
    header("Location: login.php");
    exit;
}
// 获取当前登录的用户名
$username = $_SESSION['username'];
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>主页</title>
    <style>
    body {
      background: linear-gradient(to right, #23074d, #cc5333);
      color: white;
      font-size: 24px;
        }
    </style>
</head>
<body>
    <h2>欢迎，<?php echo $username; ?>！</h2>
    <p>这是主页。</p>
    <a href="logout.php">退出登录</a>
    <a href="ly/index.php">前往学生留言墙</a>
</body>
</html>
