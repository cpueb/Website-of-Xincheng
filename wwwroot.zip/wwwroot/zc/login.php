<?php
session_start();
// 检查用户是否已登录，如果已登录则跳转到主页
if(isset($_SESSION['username'])){
    header("Location: index.php");
    exit;
}
// 处理用户提交的登录表单
if($_SERVER['REQUEST_METHOD'] == 'POST'){
    $username = $_POST['username'];
    $password = $_POST['password'];
    
    // 从文本文件中读取账号和密码对进行验证
    $accounts = file("ip.txt", FILE_IGNORE_NEW_LINES);
    $valid = false;
    foreach($accounts as $account){
        list($storedUsername, $storedPassword) = explode(",", $account);
        if(trim($username) === trim($storedUsername) && trim($password) === trim($storedPassword)){
            $valid = true;
            break;
        }
    }
    
    if($valid){
        // 将用户名存储在会话中
        $_SESSION['username'] = $username;
        // 跳转到主页
        header("Location: index.php");
        exit;
    }else{
        // 验证失败，显示错误消息
        $error = "账号或密码错误";
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>登陆</title>
    <style>
    body {
      background: linear-gradient(to right, #23074d, #cc5333);
      color: white;
      font-size: 24px;
        }
    </style>
</head>
<body>
    <h2>登陆</h2>
    <?php if(isset($error)): ?>
        <p><?php echo $error; ?></p>
    <?php endif; ?>
    <form action="" method="POST">
        <label for="username">用户名:</label>
        <input type="text" id="username" name="username" required><br><br>
        
        <label for="password">密码:</label>
        <input type="password" id="password" name="password" required><br><br>
        
        <input type="submit" value="登陆">
    </form>
    <a href="zhuc/index.php">注册账户</a>
</body>
</html>
