<?php
session_start();
// 检查用户是否已登录，如果未登录则跳转到登录页面
if(!isset($_SESSION['username'])){
    header("Location: login.php");
    exit;
}
// 处理用户提交的留言表单
if($_SERVER['REQUEST_METHOD'] == 'POST'){
    $message = $_POST['message'];
    
    // 将留言存储在会话中
    if(!isset($_SESSION['messages'])){
        $_SESSION['messages'] = array();
    }
    $_SESSION['messages'][] = $message;
    
    // 将留言保存到 ly.txt 文件中
    $file = fopen("ly.txt", "a");
    fwrite($file, $message . PHP_EOL);
    fclose($file);
}
// 读取 ly.txt 文件中的留言
$messages = array();
if(file_exists("ly.txt")){
    $file = fopen("ly.txt", "r");
    while(!feof($file)){
        $line = fgets($file);
        if(trim($line) != ""){
            $messages[] = $line;
        }
    }
    fclose($file);
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>新城中学留言板</title>
</head>
<body>
    <h2>欢迎 <?php echo $_SESSION['username']; ?>!</h2>
    
    <h3>留下一句话吧……</h3>
    <form action="" method="POST">
        <textarea name="message" rows="4" cols="50" required></textarea><br><br>
        <input type="submit" value="Submit">
    </form>
    
    <h3>留言板</h3>
    <?php if(empty($messages)): ?>
        <p>No messages yet.</p>
    <?php else: ?>
        <ul>
            <?php foreach($messages as $message): ?>
                <li><?php echo $message; ?></li>
            <?php endforeach; ?>
        </ul>
    <?php endif; ?>
    
    <p><a href="logout.php">退出登陆</a></p>
    <p><a href="pyxczx.cn">返回主页</a></p>
</body>
</html>
