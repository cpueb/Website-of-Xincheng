<?php
header("Location: http://pyxczx.cn/zc/");
exit;
?>
